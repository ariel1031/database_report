<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" type="text/css" href="css/boardDataReadstyle.css">
<?php
	$con = mysqli_connect("localhost","vivaillan137","1234","sungkyul");
    $idx_d = $_POST["idx"]; //$_POST - 양식(form)으로 전송된 데이터 받기

    $sql = "DELETE FROM board WHERE idx=$idx_d";
    mysqli_query($con, $sql);

    $sql = "SELECT * FROM board";
    $result = mysqli_query($con, $sql);

    print"<div>"."삭제결과"."</div>";
    while($row = mysqli_fetch_assoc($result)) {
    	$idx=$row['idx'];
        print"<article>"."<div class='titleEle'>"."<label>".$row['title']."</label>"."</div>";
        print"<div class='infoEle'>"."<label class = authorEle>".$row['author']."</label>";
        print"<label class = timeEle>".$row['time']."</label>";
        print"<label class='idxEle'>".$idx."번 게시물"."</label>"."</div>";
        print"<div class='contentsEle'>".$row['contents']."</div>"."</article>"."<br>";
    }
    print "<br><a href='./todaysDiary.html'>메인 화면으로</a>";
 ?>
</html>