<html>
<!-- <meta charset="utf-8"> -->
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<?php

	$host = 'localhost';
	$user = 'vivaillan137';
	$pw = '1234';
	$dbName = 'sungkyul';
	$mysqli = new mysqli($host, $user, $pw, $dbName);


    $title = $_POST['dtitle'];
    $title = addslashes($title);

    $contents = $_POST['contents'];
    $contents = addslashes($contents);

    $author = $_POST['author'];
    $author = addslashes($author);

    $password = $_POST['pw'];
    $password = addslashes($password);

    $obj = new DateTime();
    $obj->setTimezone(new DateTimeZone('Asia/Seoul'));
    $time = $obj->format('Y-m-d H:i:s');

    $sql = "insert into board (title, contents, author, password, time)";
    $sql = $sql. "values ('$title', '$contents', '$author', '$password', '$time')";

	if($mysqli->query($sql)){
    echo '<script>alert("success inserting")</script>';
	}else{
    echo '<script>alert("fail to insert sql")</script>';
	}

	mysqli_close($mysqli);

?>

<script>
	location.href = "todaysDiary.html";
</script>

</html>
